import pygame
from pygame.locals import *
from random import *
from math import *

class Barre:
    
    def __init__(self, image, pos_x = 0, pos_y = 0):
        self.image = pygame.image.load(image)
        self.long = 
        