def variation(gauche, y_ball):
    droite = gauche + 186
    largeur = droite - gauche
    degre = (gauche +(largeur / 2)) - y_ball
    degre /= -largeur / 2
    return degre
    
    

print(variation(200, 293)) # renvoie 0
print(variation(200, 339.5)) # renvoie 0.5
print(variation(200, 246.5)) # renvoie -0.5
print(variation(200, 386)) # renvoie 1
    
    